# Car3D Android APK

Android app that displays the bundled `car_model.glb` model using Three.js inside a WebView. The model and Three.js JavaScript modules are packaged into the APK, so viewing works offline after installation.

## Build on GitHub using only Android

1. Create a GitHub repository, e.g. `Car3D-Android`.
2. Upload the *contents* of this folder to the repository root, keeping `.github/workflows/build-apk.yml` in its exact path.
3. Open the repository's **Actions** tab.
4. Select **Build Car3D Android APK** and press **Run workflow** (or wait for the push-triggered run).
5. Open the completed run, scroll to **Artifacts**, and download `car3d-debug-apk`.
6. Extract the downloaded ZIP and install `app-debug.apk` on your Android phone. Android may ask you to allow installation from that source.

## Controls
- Drag one finger to rotate the view.
- Pinch with two fingers to zoom.
- Use **Автовращение** to toggle automatic rotation.
- Use **Сброс вида** to reset the camera.

## Project notes
- The model is a stylized sample car, not an exact model of a real make/model.
- This workflow builds a debug APK, not a Play Store release.
- The GitHub Actions run has not been executed in your repository yet. If it fails, open the failed step and share its error log.
